# Dashboard Manager Panel Plugin

This Panel Plugin allows users to deploy dashboards based on GitLab-files across multiple Grafana-Instances.
