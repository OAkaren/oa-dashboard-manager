import React from 'react';
// import { useHistory } from 'react-router-dom';
import { Button, LoadingPlaceholder, Tooltip } from '@grafana/ui';
import { TableCell } from './TableCell';
import { CurrentDeploymentConfig } from '../types';
import { fetchDashboardDetails } from '../functions/gitlab';
import { getCurrentDeployment, deployDashboard, fetchFolders } from '../functions/grafana';
import { useTrigger } from '../functions/hooks';

interface CustomTableRowValue {
  currentDeployments: CurrentDeploymentConfig[];
  lastCommitMessage: string;
  mostRecentVersion: string;
}

export const CustomTableRow: React.FC<any> = (props) => {
  const [value, setValue] = React.useState<CustomTableRowValue>({
    currentDeployments: [],
    lastCommitMessage: '',
    mostRecentVersion: '',
  });
  const { dashboardArray, gitLabAccessToken, gitLabBranch, gitLabProjectId, gitLabUrl } = props.options;
  const [loading, setLoading] = React.useState(false);

  const [refreshValue, refresh] = useTrigger();

  React.useEffect(() => {
    setValue({ ...value, mostRecentVersion: '', lastCommitMessage: '' });
    (async () => {
      try {
        setLoading(true);
        const { version, message } = await fetchDashboardDetails(
          gitLabUrl,
          gitLabProjectId,
          gitLabBranch,
          gitLabAccessToken,
          props.name
        );

        const currDeployments = await getCurrentDeployment(dashboardArray, props.name);

        setValue({
          ...value,
          mostRecentVersion: version,
          lastCommitMessage: message,
          currentDeployments: currDeployments,
        });
        setLoading(false);
      } catch (error) {
        console.error(error);
        setLoading(false);
      }
    })();
    // eslint-disable-next-line
  }, [props.refresh, refreshValue]);

  return (
    <>
      <tr>
        <TableCell>{props.name}</TableCell>
        <TableCell>
          {loading ? (
            <LoadingPlaceholder style={{ marginBottom: 0 }} text="Loading..." />
          ) : (
            <div style={{ display: 'flex', gap: '5px 10px', flexWrap: 'wrap' }}>
              {value.currentDeployments.map(
                ({ color, version, name, dashboardUrl, uid, fontColor }) =>
                  version != null && (
                    <Tooltip content="Open in new tab" placement="bottom">
                      <Button
                        onClick={() => {
                          window?.open(`${dashboardUrl}/d/${uid}`, '_blank')?.focus();
                        }}
                        size="sm"
                        style={{ backgroundColor: color, color: fontColor }}
                      >
                        {name}: {version}
                      </Button>
                    </Tooltip>
                  )
              )}
            </div>
          )}
        </TableCell>
        <TableCell>
          {loading ? <LoadingPlaceholder style={{ marginBottom: 0 }} text="Loading..." /> : value.mostRecentVersion}
        </TableCell>
        <TableCell>
          {loading ? <LoadingPlaceholder style={{ marginBottom: 0 }} text="Loading..." /> : value.lastCommitMessage}
        </TableCell>
        <TableCell>
          <div style={{ display: 'flex', gap: '5px 10px', flexWrap: 'wrap' }}>
            {value.currentDeployments.map(
              ({ color, version, name, dashboardUrl, uid, fontColor, dashboardName, grafanaApiKey }, index) => (
                <Button
                  key={index}
                  size="sm"
                  variant="secondary"
                  // disabled={version === value.mostRecentVersion}
                  onClick={() => {
                    props.setModalState({
                      ...props.modalState,
                      isOpen: true,
                      dashboardName: props.name,
                      grafanaName: name,
                      onConfirm: (folderName: string, folderUid: string) => {
                        return new Promise<void>(async (resolve, reject) => {
                          await deployDashboard(
                            dashboardName,
                            dashboardUrl,
                            grafanaApiKey,
                            uid,
                            props.gitlabData,
                            folderName,
                            folderUid
                          );
                          resolve();
                        });
                      },
                      onSuccess: () => {
                        refresh();
                      },
                      fetchFolders: () => {
                        return new Promise<void>(async (resolve, reject) => {
                          try {
                            const data = await fetchFolders(dashboardUrl, grafanaApiKey);
                            resolve(data);
                          } catch (error) {
                            resolve();
                          }
                        });
                      },
                    });
                    // deployDashboard(dashboardName, dashboardUrl, grafanaApiKey, uid, props.gitlabData);
                  }}
                >
                  Deploy to {name}
                </Button>
              )
            )}
          </div>
        </TableCell>
      </tr>
    </>
  );
};
