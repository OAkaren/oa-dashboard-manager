import React from 'react';

interface ModalTitleProps {
  grafanaName: string;
  dashboardName: string;
}

export const CustomModalTitle: React.FC<ModalTitleProps> = ({ grafanaName, dashboardName }) => {
  return (
    <div style={{ fontWeight: 'normal' }}>
      <h2>
        Deploy <b>{dashboardName}</b> to <b>{grafanaName}</b>
      </h2>
    </div>
  );
};
