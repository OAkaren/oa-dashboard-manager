import React from 'react';
import {
  useTheme,
  Pagination,
  Input,
  Icon,
  IconButton,
  InlineField,
  Select,
  LoadingPlaceholder,
  RefreshPicker,
} from '@grafana/ui';
import { CustomTableRow } from './CustomTableRow';

import { useTrigger } from '../functions/hooks';
import { onPanelRefresh } from '../functions/panel';
import { CustomModal } from './CustomModal';
import { CustomModalTitle } from './CustomModalTitle';

const parseIntervalStringToMs = (interval: string) => {
  const number = parseInt((interval.match(/\d*/) || []).join(''), 10);
  const unit = interval.replace(/\d*/, '');

  const unitMap = new Map();

  unitMap.set('s', 1000);
  unitMap.set('m', 60 * 1000);
  unitMap.set('h', 60 * 60 * 1000);

  return number * unitMap.get(unit);
};

export const CustomTable: React.FC<any> = ({ options }) => {
  const theme = useTheme();

  const [dashboardNames, setDashboardNames] = React.useState<string[]>();
  const [filteredDashboardNames, setFilteredDashboardNames] = React.useState<string[]>();
  const [page, setPage] = React.useState(1);
  const [pageCount, setPageCount] = React.useState(1);
  const [itemsPerPage, setItemsPerPage] = React.useState(10);
  const [loading, setLoading] = React.useState(false);
  const [triggerValue, trigger] = useTrigger();
  const [filter, setFilter] = React.useState({ name: '' });
  const [sort, setSort] = React.useState({ name: 1 });
  const [refreshIntervalValue, setRefreshIntervalValue] = React.useState('5m');
  // const [refreshTimeout, setRefreshTimout] = React.useState<NodeJS.Timeout>();

  let refreshTimeout: any;

  const [gitLabData, setGitLabData] = React.useState({
    gitLabAccessToken: '',
    gitLabBranch: '',
    gitLabProjectId: '',
    gitLabUrl: '',
  });

  const { CustomEditor } = options;

  React.useEffect(() => {
    setGitLabData(CustomEditor);
    // eslint-disable-next-line
  }, [options?.CustomEditor]);

  const [modalState, setModalState] = React.useState({
    isOpen: false,
    onConfirm: () => {},
    onSuccess: () => {},
    fetchFolders: () => {},
    dashboardName: '',
    grafanaName: '',
  });

  const setNewTimeout = () => {
    if (refreshTimeout) {
      clearTimeout(refreshTimeout);
    }
    if (refreshIntervalValue) {
      refreshTimeout = setTimeout(() => {
        onPanelRefresh(
          options,
          setLoading,
          (n: any) => {
            setDashboardNames(n);
          },
          trigger
        );
      }, parseIntervalStringToMs(refreshIntervalValue));
    }
  };

  const resetModalState = () => {
    setModalState({
      isOpen: false,
      onConfirm: () => {},
      onSuccess: () => {},
      fetchFolders: () => {},
      dashboardName: '',
      grafanaName: '',
    });
  };

  React.useEffect(() => {
    setNewTimeout();
    return () => {
      clearTimeout(refreshTimeout);
    };
    // eslint-disable-next-line
  }, [refreshIntervalValue, triggerValue, page, filter, sort]);

  React.useEffect(() => {
    if (sort.name === 1) {
      setFilteredDashboardNames(
        (dashboardNames || [])
          .filter((name) => new RegExp(filter.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i').test(name))
          .sort(function (a: string, b: string) {
            return a.toLowerCase().localeCompare(b.toLowerCase());
          })
      );
    } else {
      setFilteredDashboardNames(
        (dashboardNames || [])
          .filter((name) => new RegExp(filter.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i').test(name))
          .sort(function (a: string, b: string) {
            return a.toLowerCase().localeCompare(b.toLowerCase());
          })
          .reverse()
      );
    }
    trigger();
    // eslint-disable-next-line
  }, [filter, dashboardNames, sort]);

  React.useEffect(() => {
    if (filteredDashboardNames) {
      setPage(1);
      setPageCount(Math.ceil(filteredDashboardNames.length / itemsPerPage));
    }
  }, [filteredDashboardNames, itemsPerPage]);

  React.useEffect(() => {
    trigger();
    // eslint-disable-next-line
  }, [page, itemsPerPage]);

  React.useEffect(() => {
    onPanelRefresh(
      options,
      setLoading,
      (n: any) => {
        setDashboardNames(n);
      },
      trigger
    );
    // eslint-disable-next-line
  }, [options]);

  return (
    <>
      <div style={{ overflowX: 'auto', maxHeight: 'calc(100% - 68px)' }}>
        <table
          style={{
            width: '100%',
            borderCollapse: 'collapse',
            border: `1px solid ${theme.colors.panelBorder}`,
          }}
        >
          <tr style={{ border: `1px solid ${theme.colors.panelBorder}` }}>
            <th
              style={{
                border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                backgroundColor: theme.colors.bg2,
              }}
            >
              <div
                style={{ display: 'flex', justifyContent: 'space-between', cursor: 'pointer' }}
                onClick={() => {
                  setSort({ name: sort.name * -1 });
                }}
              >
                <div>Dashboard Name</div>
                <div style={{ display: 'flex', justifyContent: 'center' }}>
                  {
                    <IconButton
                      onClick={() => {
                        setSort({ name: sort.name * -1 });
                      }}
                      name={sort.name === 1 ? 'arrow-down' : 'arrow-up'}
                      size="lg"
                    ></IconButton>
                  }
                </div>
              </div>
            </th>
            <th
              style={{
                border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                backgroundColor: theme.colors.bg2,
              }}
            >
              Current Deployments
            </th>
            <th
              style={{
                border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                backgroundColor: theme.colors.bg2,
              }}
            >
              Version to deploy
            </th>
            <th
              style={{
                border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                backgroundColor: theme.colors.bg2,
              }}
            >
              Last commit message
            </th>
            <th
              style={{
                border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                backgroundColor: theme.colors.bg2,
              }}
            >
              Action
            </th>
          </tr>
          <tr style={{ border: `1px solid ${theme.colors.panelBorder}` }}>
            <td
              style={{
                // border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 1}px`,
                backgroundColor: theme.colors.bg2,
              }}
            >
              <Input
                value={filter.name}
                onChange={(e) => {
                  const element = e.currentTarget as HTMLInputElement;

                  setFilter({ name: element.value });
                }}
                placeholder={'Search Dashboard ...'}
                addonAfter={
                  <div style={{ width: '32px', textAlign: 'center' }}>
                    <Icon name="search" />
                  </div>
                }
              />{' '}
            </td>
            <td
              style={{
                border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                backgroundColor: theme.colors.bg2,
              }}
            ></td>
            <td
              style={{
                border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                backgroundColor: theme.colors.bg2,
              }}
            ></td>
            <td
              style={{
                border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                backgroundColor: theme.colors.bg2,
              }}
            ></td>
            <td
              style={{
                border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                backgroundColor: theme.colors.bg2,
              }}
            ></td>
          </tr>
          {(filteredDashboardNames || []).length > 0 ? (
            (filteredDashboardNames || [])
              .slice((page - 1) * itemsPerPage, page * itemsPerPage)
              .map((name, index) => (
                <CustomTableRow
                  key={index}
                  name={name}
                  options={options?.CustomEditor}
                  dashboardArray={options?.CustomEditor?.dashboardArray}
                  refresh={triggerValue}
                  gitlabData={gitLabData}
                  setModalState={setModalState}
                  modalState={modalState}
                  resetModalState={resetModalState}
                />
              ))
          ) : (
            <tr>
              <td colSpan={5} style={{ textAlign: 'center' }}>
                {loading ? (
                  <LoadingPlaceholder style={{ marginBottom: 0 }} text="Fetching Dashboard Names..." />
                ) : (
                  'No data available'
                )}
              </td>
            </tr>
          )}
        </table>
      </div>
      <div
        style={{
          height: '152px',
          marginTop: '8px',
          position: 'relative',
          justifyContent: 'center',
          verticalAlign: 'center',
        }}
      >
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <div style={{ margin: 'auto' }}>
            <Pagination
              currentPage={page}
              numberOfPages={pageCount}
              onNavigate={(newPage) => {
                setPage(newPage);
              }}
            />
          </div>
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <InlineField label="Rows per page">
              <Select
                menuShouldPortal
                width={10}
                onChange={(e) => {
                  if (e.value?.toString()) {
                    setItemsPerPage(e.value);
                  }
                }}
                value={itemsPerPage}
                options={[
                  { value: 5, label: '5' },
                  { value: 10, label: '10' },
                  { value: 15, label: '15' },
                  { value: 20, label: '20' },
                ]}
              />
            </InlineField>
          </div>
        </div>

        <div style={{ position: 'absolute', top: '0px', right: '0px' }}>
          <RefreshPicker
            value={refreshIntervalValue}
            tooltip="Refresh panel"
            intervals={['30s', '1m', '5m']}
            onRefresh={() => {
              onPanelRefresh(
                options,
                setLoading,
                (n: any) => {
                  setDashboardNames(n);
                },
                trigger
              );
              setNewTimeout();
            }}
            onIntervalChanged={(interval) => {
              setRefreshIntervalValue(interval);
            }}
            isLoading={loading}
          />
        </div>
      </div>
      <CustomModal
        isOpen={modalState.isOpen}
        onDismiss={() => {
          setModalState({ ...modalState, isOpen: false });
        }}
        onConfirm={modalState.onConfirm}
        title={CustomModalTitle({ dashboardName: modalState.dashboardName, grafanaName: modalState.grafanaName })}
        refresh={() => {
          onPanelRefresh(
            options,
            setLoading,
            (n: any) => {
              setDashboardNames(n);
            },
            trigger
          );
          trigger();
        }}
        onSuccess={modalState.onSuccess}
        onOpen={() => {
          if (refreshTimeout) {
            clearTimeout(refreshTimeout);
          }
        }}
        fetchFolders={modalState.fetchFolders}
      />
    </>
  );
};
