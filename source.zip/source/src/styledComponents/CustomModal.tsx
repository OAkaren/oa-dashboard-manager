import React from 'react';
import { Modal, Button, LoadingPlaceholder, ValuePicker, Input } from '@grafana/ui';
import { SelectableValue } from '@grafana/data';

export const CustomModal: React.FC<any> = (props) => {
  const loadFolders = async () => {
    setFetching(true);
    try {
      const data = await props.fetchFolders();
      setApiFolders(
        data.map((folder: any) => {
          return { value: folder.uid, label: folder.title };
        })
      );
    } catch (e: any) {}
    setFetching(false);
  };

  React.useEffect(() => {
    if (props.isOpen === true) {
      resetStates();
      props.onOpen();
      loadFolders();
    }
    // eslint-disable-next-line
  }, [props.isOpen]);

  const [loading, setLoading] = React.useState(false);
  const [fetching, setFetching] = React.useState(false);

  const [value, setValue] = React.useState<any>({ value: null, label: '' });
  const [apiFolders, setApiFolders] = React.useState([]);

  const resetStates = () => {
    setLoading(false);
    setApiFolders([]);
    setValue({ value: null, label: '' });
  };

  return (
    <Modal title={props.title} isOpen={props.isOpen} onDismiss={props.onDismiss}>
      <h5>
        Please select a folder, defaults to <b>General</b>. You may also enter a new folder name.
      </h5>
      <div style={{ display: 'flex', margin: '16px 0px', gap: '8px' }}>
        <div style={{ width: '50%' }}>
          <ValuePicker
            size="md"
            icon={fetching ? 'cloud-download' : 'arrow-down'}
            label={fetching ? 'Loading Folders ...' : 'Select Folder'}
            options={apiFolders}
            onChange={(e: SelectableValue) => setValue(e)}
          />
        </div>
        <div style={{ width: '50%' }}>
          <Input
            value={value.label}
            placeholder={'Enter a folder name'}
            onChange={(e) => {
              const element = e.currentTarget as HTMLInputElement;

              const apiFolder: any = apiFolders.find((folder: any) => folder.label === element.value);

              setValue({ value: apiFolder?.value || null, label: element.value });
            }}
          />
        </div>
      </div>
      <Modal.ButtonRow>
        <Button
          onClick={() => {
            props.onDismiss();
          }}
          variant="destructive"
        >
          Cancel
        </Button>
        <Button
          variant="primary"
          disabled={loading || fetching}
          onClick={async () => {
            setLoading(true);
            await props.onConfirm(value.label, value.value);
            setLoading(false);
            props.onSuccess();
            props.onDismiss();
          }}
        >
          {loading || fetching ? (
            <LoadingPlaceholder style={{ marginBottom: 0 }} text="Loading..." />
          ) : (
            'Deploy Dashboard'
          )}
        </Button>
      </Modal.ButtonRow>
    </Modal>
  );
};
