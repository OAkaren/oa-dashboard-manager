import React from 'react';
import { useTheme } from '@grafana/ui';

export const TableCell: React.FC = (props) => {
  const theme = useTheme();
  return (
    <td
      style={{
        border: `1px solid ${theme.colors.panelBorder}`,
        padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
        ...props,
      }}
      {...props}
    >
      {props.children}
    </td>
  );
};
