import { AxiosError } from 'axios';

export interface SimpleOptions {
  CustomEditor: CustomPanelOptions;
}

export interface DashboardConfig {
  grafanaUrl: string;
  grafanaDisplayName: string;
  color: string;
  fontColor: string;
  grafanaApiKey: string;
}

export interface CustomPanelOptions {
  gitLabBranch: string;
  gitLabProjectId: string;
  gitLabUrl: string;
  gitLabAccessToken: string;
  dashboardArray: DashboardConfig[];
}

export interface FetchDashboardDetailsResponse {
  error: boolean | AxiosError | Error;
  version: string | null;
}

export interface CurrentDeploymentConfig {
  version: string | null;
  name: string;
  uid: string;
  dashboardUrl: string;
  dashboardName: string;
  grafanaApiKey: string;
  color: string;
  fontColor: string;
}

export interface GitLabData {
  gitLabAccessToken: string;
  gitLabBranch: string;
  gitLabProjectId: string;
  gitLabUrl: string;
}
