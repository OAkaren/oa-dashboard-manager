import { PanelPlugin } from '@grafana/data';
import { SimpleOptions } from './types';
import { SimplePanel } from './SimplePanel';
import { SimpleEditor } from './SimpleEditor';

export const plugin = new PanelPlugin<SimpleOptions>(SimplePanel).setPanelOptions((builder) => {
  return (
    builder
      // .addTextInput({
      //   path: 'text',
      //   name: 'Simple text option',
      //   description: 'Description of panel option',
      //   settings: {
      //     placeholder: 'TESTER2',
      //     maxLength: 3,
      //   },
      // })
      // .addBooleanSwitch({
      //   path: 'showSeriesCount',
      //   name: 'Show series counter',
      //   defaultValue: true,
      // })
      // .addRadio({
      //   path: 'seriesCountSize',
      //   defaultValue: 'lg',
      //   name: 'Series counter size',
      //   settings: {
      //     options: [
      //       {
      //         value: 'sm',
      //         label: 'Small',
      //       },
      //       {
      //         value: 'md',
      //         label: 'Medium',
      //       },
      //       {
      //         value: 'lg',
      //         label: 'Large',
      //       },
      //     ],
      //   },
      //   showIf: (config) => config.showSeriesCount,
      // })
      // .addRadio({
      //   path: 'color',
      //   name: 'Circle color',
      //   defaultValue: 'red',
      //   settings: {
      //     options: [
      //       {
      //         value: 'red',
      //         label: 'Red',
      //       },
      //       {
      //         value: 'green',
      //         label: 'Green',
      //       },
      //       {
      //         value: 'blue',
      //         label: 'Blue',
      //       },
      //     ],
      //   },
      // })
      .addCustomEditor({
        id: 'CustomEditor',
        path: 'CustomEditor',
        name: 'Grafana & GitLab Configuration',
        editor: SimpleEditor,
      })
  );
});
