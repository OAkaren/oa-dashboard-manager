import React from 'react';
import { Button, Input, Label, useTheme, ColorPicker, IconButton, Tooltip } from '@grafana/ui';
import { StandardEditorProps, AppEvents } from '@grafana/data';
import { DashboardConfig, CustomPanelOptions } from './types';
import { healthCheck } from './functions/gitlab';
import { getContrast } from './functions/contrastCalculator';

import { SystemJS } from '@grafana/runtime';

export const SimpleEditor: React.FC<StandardEditorProps<CustomPanelOptions>> = ({
  value = { gitLabBranch: '', gitLabProjectId: '', gitLabUrl: '', gitLabAccessToken: '', dashboardArray: [] },
  onChange,
}) => {
  const theme = useTheme();
  const [grafanaUrl, setGrafanaUrl] = React.useState('');
  const [gitLabUrl, setGitLabUrl] = React.useState(value.gitLabUrl);
  const [gitLabProjectId, setGitLabProjectId] = React.useState(value.gitLabProjectId);
  const [gitLabBranch, setGitLabBranch] = React.useState(value.gitLabBranch);
  const [accessToken, setAccessToken] = React.useState(value.gitLabAccessToken);
  const [grafanaDisplayName, setGrafanaDisplayName] = React.useState('');
  const [grafanaApiKey, setGrafanaApiKey] = React.useState('');

  return (
    <>
      <h4 style={{ marginTop: '20px', marginBottom: '12px' }}>Grafana Instances Configuration</h4>
      <Label>Grafana Instance URL</Label>
      <div style={{ marginBottom: '12px' }}>
        <Input
          onChange={(e) => {
            const element = e.currentTarget as HTMLInputElement;
            setGrafanaUrl(element.value);
          }}
          value={grafanaUrl}
        />
      </div>

      <Label>Grafana Instance Display Name</Label>
      <div style={{ marginBottom: '12px' }}>
        <Input
          onChange={(e) => {
            const element = e.currentTarget as HTMLInputElement;
            setGrafanaDisplayName(element.value);
          }}
          value={grafanaDisplayName}
        />
      </div>

      <Label>Grafana Instance API Key</Label>
      <div style={{ marginBottom: '12px' }}>
        <Input
          onChange={(e) => {
            const element = e.currentTarget as HTMLInputElement;
            setGrafanaApiKey(element.value);
          }}
          value={grafanaApiKey}
        />
      </div>

      <Button
        onClick={() => {
          onChange({
            ...value,
            dashboardArray: (value.dashboardArray || []).concat({
              grafanaUrl: grafanaUrl,
              grafanaDisplayName: grafanaDisplayName,
              color: '#F2495C',
              fontColor: getContrast('#F2495C') || '#FFFFFF',
              grafanaApiKey: grafanaApiKey,
            }),
          });
          setGrafanaUrl('');
          setGrafanaDisplayName('');
          setGrafanaApiKey('');
        }}
        disabled={!grafanaDisplayName || !grafanaUrl || !grafanaApiKey}
      >
        Add Grafana Instance
      </Button>

      <div style={{ overflowX: 'auto', marginBottom: '4px' }}>
        <table
          style={{
            width: '100%',
            borderCollapse: 'collapse',
            border: `1px solid ${theme.colors.panelBorder}`,
            marginTop: theme.spacing.base,
          }}
        >
          <tr style={{ border: `1px solid ${theme.colors.panelBorder}` }}>
            <th
              style={{
                border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                backgroundColor: theme.colors.bg2,
              }}
            >
              Grafana Instance URL
            </th>
            <th
              style={{
                border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                backgroundColor: theme.colors.bg2,
              }}
            >
              Name
            </th>
            <th
              style={{
                border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                backgroundColor: theme.colors.bg2,
              }}
            >
              API Key
            </th>
            <th
              style={{
                border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                backgroundColor: theme.colors.bg2,
              }}
            >
              Color
            </th>
            <th
              style={{
                border: `1px solid ${theme.colors.panelBorder}`,
                padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                backgroundColor: theme.colors.bg2,
              }}
            >
              Action
            </th>
          </tr>

          {(value.dashboardArray || []).length > 0 ? (
            (value.dashboardArray || []).map((dashboardConfig: DashboardConfig, index: number) => {
              return (
                <tr key="index">
                  <td
                    style={{
                      border: `1px solid ${theme.colors.panelBorder}`,
                      padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                    }}
                  >
                    {dashboardConfig.grafanaUrl}
                  </td>
                  <td
                    style={{
                      border: `1px solid ${theme.colors.panelBorder}`,
                      padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                    }}
                  >
                    {dashboardConfig.grafanaDisplayName}
                  </td>
                  <Tooltip content="Copy to clipboard" placement="bottom">
                    <td
                      style={{
                        border: `1px solid ${theme.colors.panelBorder}`,
                        padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                        textOverflow: 'ellipsis',
                        overflow: 'hidden',
                        whiteSpace: 'nowrap',
                        minWidth: '100px',
                        maxWidth: '100px',
                        cursor: 'pointer',
                      }}
                      onClick={() => {
                        navigator.clipboard.writeText(dashboardConfig.grafanaApiKey);
                        SystemJS.load('app/core/app_events').then((appEvents: any) => {
                          appEvents.emit(AppEvents.alertSuccess, ['Copied to Clipboard!']);
                        });
                      }}
                    >
                      {dashboardConfig.grafanaApiKey}
                    </td>
                  </Tooltip>
                  <td
                    style={{
                      border: `1px solid ${theme.colors.panelBorder}`,
                      padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'center' }}>
                      <ColorPicker
                        color={dashboardConfig.color}
                        onChange={(e) => {
                          const valueCopy = value;
                          valueCopy.dashboardArray[index].color = e;
                          const fontColor = getContrast(e);
                          valueCopy.dashboardArray[index].fontColor = fontColor || '#FFFFFF';
                          onChange(valueCopy);
                        }}
                      />
                    </div>
                  </td>
                  <td
                    style={{
                      border: `1px solid ${theme.colors.panelBorder}`,
                      padding: `${theme.spacing.base * 0.5}px ${theme.spacing.base * 2}px`,
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'center' }}>
                      <IconButton
                        name="trash-alt"
                        size="lg"
                        onClick={() => {
                          const dbArray = value.dashboardArray;
                          dbArray.splice(index, 1);
                          onChange({
                            ...value,
                            dashboardArray: dbArray,
                          });
                        }}
                      ></IconButton>
                    </div>
                  </td>
                </tr>
              );
            })
          ) : (
            <tr>
              <td colSpan={5} style={{ textAlign: 'center' }}>
                No data available
              </td>
            </tr>
          )}
        </table>
      </div>

      <h4 style={{ marginTop: '20px', marginBottom: '12px' }}>GitLab Configuration</h4>

      <Label>GitLab Instance URL</Label>
      <div style={{ marginBottom: '12px' }}>
        <Input
          onChange={(e) => {
            const element = e.currentTarget as HTMLInputElement;
            setGitLabUrl(element.value);
            // onChange({ ...value, gitLabUrl: element.value });
          }}
          value={gitLabUrl}
        />
      </div>

      <Label>GitLab Access Token</Label>
      <div style={{ marginBottom: '12px' }}>
        <Input
          onChange={(e) => {
            const element = e.currentTarget as HTMLInputElement;
            setAccessToken(element.value);
            // onChange({ ...value, gitLabAccessToken: element.value });
          }}
          value={accessToken}
        />
      </div>
      <Label>GitLab Project ID</Label>

      <div style={{ marginBottom: '12px' }}>
        <Input
          onChange={(e) => {
            const element = e.currentTarget as HTMLInputElement;
            setGitLabProjectId(element.value);
            // onChange({ ...value, gitLabProjectId: element.value });
          }}
          value={gitLabProjectId}
        />
      </div>

      <Label>GitLab Branch</Label>
      <div style={{ marginBottom: '12px' }}>
        <Input
          onChange={(e) => {
            const element = e.currentTarget as HTMLInputElement;
            // onChange({ ...value, gitLabBranch: element.value });
            setGitLabBranch(element.value);
          }}
          value={gitLabBranch}
        />
      </div>

      <Button
        onClick={async () => {
          onChange({
            ...value,
            gitLabBranch: gitLabBranch,
            gitLabProjectId: gitLabProjectId,
            gitLabAccessToken: accessToken,
            gitLabUrl: gitLabUrl,
          });
          await healthCheck(gitLabUrl, gitLabProjectId, gitLabBranch, accessToken);
        }}
      >
        {'Test & apply'}
      </Button>
    </>
  );
};
