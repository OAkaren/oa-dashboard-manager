import axios, { AxiosError } from 'axios';
import { SystemJS } from '@grafana/runtime';
import { AppEvents } from '@grafana/data';

interface DashboardDetailResponse {
  version: string;
  message: string;
}

interface DashboardResponse {
  version: string;
  decodedContent: string;
  error: boolean | AxiosError | Error;
}

export function healthCheck(
  gitLabUrl: string,
  gitLabProjectId: string,
  gitLabBranch: string,
  gitLabAccessToken: string
) {
  return new Promise<void>(async (resolve, reject) => {
    try {
      await axios.get(`${gitLabUrl}/api/v4/projects/${gitLabProjectId}/repository/branches/${gitLabBranch}`, {
        headers: {
          Authorization: `Bearer ${gitLabAccessToken}`,
        },
        // httpAgent: agent,
      });

      SystemJS.load('app/core/app_events').then((appEvents: any) => {
        appEvents.emit(AppEvents.alertSuccess, ['GitLab was validated']);
      });

      resolve();
    } catch (error: any) {
      SystemJS.load('app/core/app_events').then((appEvents: any) => {
        appEvents.emit(AppEvents.alertError, [
          `An error when validating Gitlab: ${error.name}: ${error?.response?.data?.message || error.message}`,
        ]);
      });
      resolve();
    }
  });
}

export function fetchDashboards(
  gitLabUrl: string,
  gitLabProjectId: string,
  gitLabBranch: string,
  gitLabAccessToken: string,
  page = 1,
  arr = []
) {
  return new Promise(async (resolve, reject) => {
    try {
      const { data, headers } = await axios.get(
        `${gitLabUrl}/api/v4/projects/${gitLabProjectId}/repository/tree?ref=${gitLabBranch}&page=${page}`,
        {
          headers: {
            Authorization: `Bearer ${gitLabAccessToken}`,
          },
        }
      );
      arr = arr.concat(data.filter((file: any) => /.* \[.*\].json/.test(file?.name)).map((file: any) => file.name));
      if (headers['x-next-page']) {
        const newArray = await fetchDashboards(
          gitLabUrl,
          gitLabProjectId,
          gitLabBranch,
          gitLabAccessToken,
          headers['x-next-page'],
          arr
        );
        resolve(newArray);
      } else {
        resolve(arr);
      }
    } catch (error) {
      reject(error);
    }
  });
}

export function fetchDashboardDetails(
  gitLabUrl: string,
  gitLabProjectId: string,
  gitLabBranch: string,
  gitLabAccessToken: string,
  gitLabFileName: string
) {
  return new Promise<DashboardDetailResponse>(async (resolve, reject) => {
    try {
      const { data: fileData } = await axios.get(
        `${gitLabUrl}/api/v4/projects/${gitLabProjectId}/repository/files/${gitLabFileName}?ref=${gitLabBranch}`,
        {
          headers: {
            Authorization: `Bearer ${gitLabAccessToken}`,
          },
        }
      );

      const { content, last_commit_id } = fileData;
      const version = JSON.parse(atob(content))?.version;

      if (!version) {
        reject({ message: 'Unable to identify Dashboard version.' });
      }

      const { data: commitData } = await axios.get(
        `${gitLabUrl}/api/v4/projects/${gitLabProjectId}/repository/commits/${last_commit_id}?ref=${gitLabBranch}`,
        {
          headers: {
            Authorization: `Bearer ${gitLabAccessToken}`,
          },
        }
      );

      const message = commitData?.message || '';

      resolve({ version, message });
    } catch (error) {
      reject(error);
    }
  });
}

export function fetchDashboard(
  gitLabUrl: string,
  gitLabProjectId: string,
  gitLabBranch: string,
  gitLabAccessToken: string,
  gitLabFileName: string
) {
  return new Promise<DashboardResponse>(async (resolve, reject) => {
    try {
      const { data: fileData } = await axios.get(
        `${gitLabUrl}/api/v4/projects/${gitLabProjectId}/repository/files/${gitLabFileName}?ref=${gitLabBranch}`,
        {
          headers: {
            Authorization: `Bearer ${gitLabAccessToken}`,
          },
        }
      );

      const { content } = fileData;
      const decodedContent = atob(content);
      const version = JSON.parse(decodedContent)?.version;

      if (!version) {
        reject({ name: 'Error', message: `Unable to identify Dashboard version from GitLab file ${gitLabFileName}.` });
      }

      resolve({ version, decodedContent, error: false });
    } catch (error) {
      reject({ error });
    }
  });
}
