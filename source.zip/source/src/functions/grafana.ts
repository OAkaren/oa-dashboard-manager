import axios from 'axios';
import { SystemJS } from '@grafana/runtime';
import { AppEvents } from '@grafana/data';
import { GitLabData, FetchDashboardDetailsResponse, CurrentDeploymentConfig } from '../types';
import { fetchDashboard } from './gitlab';

export function fetchDashboardDetails(grafanaUrl: string, grafanaApiKey: string, dashboardUid: string) {
  return new Promise<FetchDashboardDetailsResponse>(async (resolve, reject) => {
    try {
      const { data } = await axios.get(`${grafanaUrl}/api/dashboards/uid/${dashboardUid}`, {
        headers: {
          Authorization: `Bearer ${grafanaApiKey}`,
        },
      });

      const { dashboard } = data;
      resolve({ version: dashboard.version, error: false });
    } catch (error: any) {
      resolve({ version: null, error: error });
    }
  });
}

export function getCurrentDeployment(dashboardArray: any[], dashboardName: string) {
  return new Promise<CurrentDeploymentConfig[]>(async (resolve, reject) => {
    try {
      let currDeployments: CurrentDeploymentConfig[] = [];
      for (let index = 0; index < dashboardArray.length; index++) {
        const dashboardUid = dashboardName.substring(dashboardName.indexOf('[') + 1, dashboardName.indexOf(']'));

        const { version: currentVersion } = await fetchDashboardDetails(
          dashboardArray[index].grafanaUrl,
          dashboardArray[index].grafanaApiKey,
          dashboardUid
        );

        currDeployments[index] = {
          version: currentVersion,
          name: dashboardArray[index].grafanaDisplayName,
          color: dashboardArray[index].color,
          fontColor: dashboardArray[index].fontColor,
          dashboardUrl: dashboardArray[index].grafanaUrl,
          grafanaApiKey: dashboardArray[index].grafanaApiKey,
          dashboardName: dashboardName,
          uid: dashboardUid,
        };
      }
      resolve(currDeployments);
    } catch (error) {
      reject({ error });
    }
  });
}

export function deployDashboard(
  dashboardName: string,
  grafanaUrl: string,
  grafanaApiKey: string,
  uid: string,
  gitLabData: GitLabData,
  folderName: string,
  folderUid: string
) {
  return new Promise<void>(async (resolve, reject) => {
    try {
      if (!folderUid) {
        // CREATE NEW FOLDER; TAKE UID FOR NEXT REQUEST
        const { data: folderData } = await axios.post(
          `${grafanaUrl}/api/folders`,
          {
            title: folderName,
          },
          {
            headers: {
              Authorization: `Bearer ${grafanaApiKey}`,
            },
          }
        );
        folderUid = folderData.uid;
      }

      const { gitLabAccessToken, gitLabBranch, gitLabProjectId, gitLabUrl } = gitLabData;

      const {
        version: gitLabVersion,
        decodedContent,
        error,
      } = await fetchDashboard(gitLabUrl, gitLabProjectId, gitLabBranch, gitLabAccessToken, dashboardName);

      if (
        (error && axios.isAxiosError(error) && error?.response?.status !== 404) ||
        (!axios.isAxiosError(error) && error instanceof Error)
      ) {
        SystemJS.load('app/core/app_events').then((appEvents: any) => {
          appEvents.emit(AppEvents.alertError, [
            `An unexpected error occurred when deploying dashboard: ${error.name}: ${
              axios.isAxiosError(error) ? error?.response?.data?.message : error.message
            }`,
          ]);
        });
      }

      try {
        await axios.delete(`${grafanaUrl}/api/dashboards/uid/${uid}`, {
          headers: {
            Authorization: `Bearer ${grafanaApiKey}`,
          },
        });
      } catch (error: any) {
        if (error?.response?.status !== 404) {
          throw error;
        }
      }
      const JSONcontent = JSON.parse(decodedContent);
      // JSONcontent.version = 1;
      JSONcontent.id = null;

      for (let i = 0; i < parseInt(gitLabVersion, 10); i++) {
        await axios.post(
          `${grafanaUrl}/api/dashboards/db`,
          {
            dashboard: JSONcontent,
            overwrite: true,
            folderUid: folderUid,
            message: 'Dashboard committed by Dashboard Manager',
          },
          {
            headers: {
              Authorization: `Bearer ${grafanaApiKey}`,
            },
          }
        );
      }
      SystemJS.load('app/core/app_events').then((appEvents: any) => {
        appEvents.emit(AppEvents.alertSuccess, ['Dashboard deployed successfully.']);
      });
      resolve();
    } catch (error: any) {
      SystemJS.load('app/core/app_events').then((appEvents: any) => {
        appEvents.emit(AppEvents.alertError, [
          `An error occurred when deploying dashboard: ${error.name}: ${
            axios.isAxiosError(error) ? error?.response?.data?.message : error.message
          }`,
        ]);
      });

      resolve();
    }
  });
}

export function fetchFolders(grafanaUrl: string, grafanaApiKey: string) {
  return new Promise<void>(async (resolve, reject) => {
    try {
      const { data } = await axios.get(`${grafanaUrl}/api/folders`, {
        headers: {
          Authorization: `Bearer ${grafanaApiKey}`,
        },
      });
      resolve(data);
    } catch (error: any) {
      SystemJS.load('app/core/app_events').then((appEvents: any) => {
        appEvents.emit(AppEvents.alertError, [
          `An error occurred when fetching Folders from API: ${error.name}: ${
            axios.isAxiosError(error) ? error?.response?.data?.message : error.message
          }`,
        ]);
      });
      resolve();
    }
  });
}
