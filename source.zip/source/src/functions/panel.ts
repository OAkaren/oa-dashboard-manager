import { SystemJS } from '@grafana/runtime';
import { AppEvents } from '@grafana/data';
import { fetchDashboards } from './gitlab';

export async function onPanelRefresh(
  options: any,
  setLoading: (loading: boolean) => void,
  setDashboardNames: (dashboardnames: any[]) => void,
  trigger: () => void
) {
  if (options?.CustomEditor) {
    const { gitLabAccessToken, gitLabBranch, gitLabProjectId, gitLabUrl } = options.CustomEditor;

    if (gitLabAccessToken && gitLabBranch && gitLabProjectId && gitLabUrl) {
      try {
        setLoading(true);
        setDashboardNames([]);
        const newDashboardNames: any = await fetchDashboards(
          gitLabUrl,
          gitLabProjectId,
          gitLabBranch,
          gitLabAccessToken
        );
        SystemJS.load('app/core/app_events').then((appEvents: any) => {
          appEvents.emit(AppEvents.alertSuccess, ['Dashboard names fetched successfully.']);
        });
        setDashboardNames(newDashboardNames);
        setLoading(false);
      } catch (error: any) {
        SystemJS.load('app/core/app_events').then((appEvents: any) => {
          appEvents.emit(AppEvents.alertError, [
            `An error occurred when fetching Dashboard names: ${error.name}: ${
              error?.response?.data?.message || error.message
            }`,
          ]);
        });
        setLoading(false);
      }
    }
  }
  trigger();
}
