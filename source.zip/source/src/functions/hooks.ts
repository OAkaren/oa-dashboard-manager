import React from 'react';

export function useApi() {}

export function useTrigger() {
  const [value, setValue] = React.useState(true);

  const trigger = () => {
    setValue(!value);
  };
  return [value, trigger] as const;
}
